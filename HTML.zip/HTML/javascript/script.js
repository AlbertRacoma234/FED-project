$(document).ready(function(){
    $("#button").click(function(){
        $("#hideko").toggle(1000);
    });
 });






 